import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-h2h',
  templateUrl: './h2h.component.html',
  styleUrls: ['./h2h.component.css']
})
export class H2hComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
